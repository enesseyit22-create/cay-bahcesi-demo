/* injected marker for Capacitor builds */
window.__KERF_NATIVE__ = true;
